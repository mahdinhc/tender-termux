package stdlib

import (
	"github.com/gonutz/wui/v2"
	"tender"
)


var windowModule = map[string]tender.Object{
	"new": &tender.UserFunction{Value: windowNew},
}

func windowNew(args ...tender.Object) (tender.Object, error) {
	if len(args) != 0 {
		return nil, tender.ErrWrongNumArguments
	}

	windowFont, _ := wui.NewFont(wui.FontDesc{
		Name:   "Tahoma",
		Height: -11,
	})

	window := wui.NewWindow()
	window.SetFont(windowFont)
	window.SetTitle("Window")

	paintBox1 := wui.NewPaintBox()
	paintBox1.SetBounds(60, 52, 485, 296)
	window.Add(paintBox1)

	// window.Show()

	return  &tender.ImmutableMap{
		Value: map[string]tender.Object{
			"show": &tender.UserFunction{Value: FuncARE(window.Show)},
			"close": &tender.UserFunction{Value: FuncAR(window.Close)},
			"destroy": &tender.UserFunction{Value: FuncAR(window.Destroy)},
		},	
	}, nil
}