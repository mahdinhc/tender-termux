package stdlib

import (
	"github.com/ebitengine/oto/v3"
	"github.com/hajimehoshi/go-mp3"
	"bytes"
	// "time"
	"tender"
)

var otoCtx *oto.Context

var audioModule = map[string]tender.Object{
	"player": &tender.UserFunction{Name: "player", Value: audioPlayer},
}

func init() {
    op := &oto.NewContextOptions{}
    op.SampleRate = 44100
    op.ChannelCount = 2
    op.Format = oto.FormatSignedInt16LE
    otoCtx, _, _ = oto.NewContext(op)
}

func audioPlayer(args ...tender.Object) (ret tender.Object, err error) {
	if len(args) != 1 {
		return nil, tender.ErrWrongNumArguments
	}

	data, _ := tender.ToByteSlice(args[0])

	buf := bytes.NewReader(data)

	decoded, err := mp3.NewDecoder(buf)
	if err != nil {
		return nil, nil
	}

	player := otoCtx.NewPlayer(decoded)

	return &tender.ImmutableMap{
		Value: map[string]tender.Object{
			"decoder" : &tender.ImmutableMap{
				Value: map[string]tender.Object{
					"length": &tender.UserFunction{
						Name:  "length",
						Value: FuncARI64(decoded.Length),
					},	
					"sample_rate": &tender.UserFunction{
						Name:  "sample_rate",
						Value: FuncARI(decoded.SampleRate),
					},	
					"seek": &tender.UserFunction{
						Name:  "seek",
						Value: FuncAI64IRI64E(decoded.Seek),
					},	
				},
			},
			"play": &tender.UserFunction{
				Name:  "play",
				Value: FuncAR(player.Play),
			},		
			"pause": &tender.UserFunction{
				Name:  "pause",
				Value: FuncAR(player.Pause),
			},	
			"is_playing": &tender.UserFunction{
				Name:  "is_playing",
				Value: FuncARB(player.IsPlaying),
			},	
			"close": &tender.UserFunction{
				Name:  "close",
				Value: FuncARE(player.Close),
			},	
			"err": &tender.UserFunction{
				Name:  "err",
				Value: FuncARE(player.Err),
			},	
			"reset": &tender.UserFunction{
				Name:  "reset",
				Value: FuncAR(player.Reset),
			},	
			"buffered_size": &tender.UserFunction{
				Name:  "buffered_size",
				Value: FuncARI(player.BufferedSize),
			},	
			"set_buffer_size": &tender.UserFunction{
				Name:  "set_buffer_size",
				Value: FuncAIR(player.SetBufferSize),
			},	
			"set_volume": &tender.UserFunction{
				Name:  "set_volume",
				Value: FuncAFR(player.SetVolume),
			},
			"volume": &tender.UserFunction{
				Name:  "volume",
				Value: FuncARF(player.Volume),
			},	
			"seek": &tender.UserFunction{
				Name:  "seek",
				Value: FuncAI64IRI64E(player.Seek),
			},
		},
	}, nil
}
