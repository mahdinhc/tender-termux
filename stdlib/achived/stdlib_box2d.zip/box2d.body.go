package stdlib

import "github.com/ByteArena/box2d"
import "tender"
import "fmt"



func makeBox2dBody(body *box2d.B2Body) *tender.ImmutableMap {
	
	return &tender.ImmutableMap{
		Value: map[string]tender.Object{
			"create_fixture" : &tender.UserFunction{
				Value: func(args ...tender.Object) (tender.Object, error) {
					if len(args) != 1 { 
						return nil, tender.ErrWrongNumArguments 
					}
					
					
					shape := box2d.MakeB2CircleShape()
					shape.M_radius = 0.5
					fixtureDef := box2d.MakeB2FixtureDef()
					fixtureDef.Shape = &shape
					fixtureDef.Density = 1.0
					fixtureDef.Friction = 0.3
					body.CreateFixtureFromDef(&fixtureDef)
					
					body.ApplyForce(box2d.B2Vec2{X: 2, Y: -10}, box2d.B2Vec2{X: 2, Y: -10}, true)
					fmt.Println(body.GetPosition(), body.GetMass())
					
					return nil, nil
				},
			},	
			"get_position" : &tender.UserFunction{
				Value: func(args ...tender.Object) (tender.Object, error) {
					if len(args) != 0 { 
						return nil, tender.ErrWrongNumArguments 
					}
					ps := body.GetPosition()
					return &tender.ImmutableMap{
						Value: map[string]tender.Object{
							"x": &tender.Float{Value: ps.X},
							"y": &tender.Float{Value: ps.Y},
						},
					}, nil
				},
			},	
			"get_linearvelocity" : &tender.UserFunction{
				Value: func(args ...tender.Object) (tender.Object, error) {
					if len(args) != 0 { 
						return nil, tender.ErrWrongNumArguments 
					}
					v := body.GetLinearVelocity()
					return &tender.ImmutableMap{
						Value: map[string]tender.Object{
							"x": &tender.Float{Value: v.X},
							"y": &tender.Float{Value: v.Y},
						},
					}, nil
				},
			},
			"get_angle" : &tender.UserFunction{
				Value: FuncARF(body.GetAngle),
			},	
			"get_angulardamping" : &tender.UserFunction{
				Value: FuncARF(body.GetAngularDamping),
			},
			"get_angularvelocity" : &tender.UserFunction{
				Value: FuncARF(body.GetAngularVelocity),
			},
			"get_gravityscale" : &tender.UserFunction{
				Value: FuncARF(body.GetGravityScale),
			},
			"get_inertia" : &tender.UserFunction{
				Value: FuncARF(body.GetInertia),
			},	
			"get_lineardamping" : &tender.UserFunction{
				Value: FuncARF(body.GetLinearDamping),
			},	
			"get_mass" : &tender.UserFunction{
				Value: FuncARF(body.GetMass),
			},	
			"get_type" : &tender.UserFunction{
				Value: FuncARu8(body.GetType),
			},
		},
	}
	
}				