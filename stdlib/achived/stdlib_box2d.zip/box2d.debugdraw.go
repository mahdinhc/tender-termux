package stdlib


import (
	"golang.org/x/exp/shiny/driver"
	"golang.org/x/exp/shiny/screen"
	
	"github.com/ByteArena/box2d"
	
	// "fmt"
	
	"tender"
	"tender/v/gg"
	
	
	"image"
	"image/color"
	"image/draw"
	"time"
)

func box2dDebugDrawFunc(world *box2d.B2World, args ...tender.Object) (tender.Object, error) {
	if len(args) != 3 { 
		return nil, tender.ErrWrongNumArguments 
	}
	
	width, _ := tender.ToInt(args[0])
	height, _ := tender.ToInt(args[1])
	title, _ := tender.ToString(args[2])
	
	driver.Main(func(s screen.Screen) {
		scale := 40.0
		window, _ := s.NewWindow(&screen.NewWindowOptions{
			Title:  title,
			Width:  width,
			Height: height,
		})
		
		defer window.Release()
		
		screenBuffer, _ := s.NewBuffer(image.Point{X: width, Y: height})
		
		defer screenBuffer.Release()
		pixBuffer := screenBuffer.RGBA()
		
		ctx := gg.NewContext(width, height)
		timeStep := 1.0 / 60.0
		
		
		for {
			world.Step(timeStep, 2, 6)
			draw.Draw(pixBuffer, pixBuffer.Bounds(), &image.Uniform{color.Black}, image.Point{}, draw.Over)
			ctx.SetHexColor("#232323")
			ctx.Clear()
			bodyList := world.GetBodyList()
			for body := bodyList; body != nil; body = body.GetNext() {
				// bodyType := body.GetType()
				for fixture := body.GetFixtureList(); fixture != nil; fixture = fixture.GetNext() {
					shape := fixture.GetShape()
					shapeType := shape.GetType()
					if shapeType == box2d.B2Shape_Type.E_circle {
						position := body.GetPosition()
						radius := shape.GetRadius() * scale
						ctx.Push()
						ctx.SetHexColor("#11ff11")
						ctx.Translate(position.X*scale, position.Y*scale)
						ctx.DrawCircle(0, 0, radius)
						ctx.Fill()
						// ctx.SetHexColor("#00ff00")
							// ctx.DrawLine(0, 0, radius, 0)
						// ctx.Stroke()
						ctx.Pop()
					} else if shapeType == box2d.B2Shape_Type.E_polygon {
						polygonShape := shape.(*box2d.B2PolygonShape)
						ctx.Push()
						ctx.SetHexColor("#1111ff") // Set the color for polygons
						ctx.NewSubPath()
						for i := 0; i < polygonShape.M_count; i++ {
							vertex := body.GetWorldPoint(polygonShape.M_vertices[i])
							ctx.LineTo(vertex.X*scale, vertex.Y*scale)
						}
						ctx.ClosePath()
						ctx.Fill()
						ctx.Pop()
					}
				}
			}
			// drawFunc(ctx)
			
			imageRGBA := ctx.Image().(*image.RGBA)
			draw.Draw(pixBuffer, screenBuffer.Bounds(), imageRGBA, image.Point{}, draw.Over)
			window.Upload(image.Point{0, 0}, screenBuffer, screenBuffer.Bounds())
			window.Publish()
			
			// time.Sleep(time.Millisecond * 16) // ~60 FPS
			time.Sleep(time.Millisecond * 16) // ~60 FPS
		}
		
	})
	
	
	return nil, nil
	
}