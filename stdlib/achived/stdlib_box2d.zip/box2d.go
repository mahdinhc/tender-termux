package stdlib

import (
	"github.com/ByteArena/box2d"
	// "fmt"
	"tender"
)



var box2dModule = map[string]tender.Object{
	"new_world": &tender.UserFunction{Name: "new_world", Value: box2dNewWorld},
}

func box2dNewWorld(args ...tender.Object) (ret tender.Object, err error) {
	if len(args) != 2 {
		return nil, tender.ErrWrongNumArguments
	}
	
	x, _ := tender.ToFloat64(args[0])
	y, _ := tender.ToFloat64(args[0])
	
	world := box2d.MakeB2World(box2d.B2Vec2{X: x, Y: y})
	
	// fmt.Println(world)
	
	return &tender.ImmutableMap{
		Value: map[string]tender.Object{
			"debugdraw" : &tender.UserFunction{
				Name: "debugdraw",
				Value: func(args ...tender.Object) (tender.Object, error) {
					return box2dDebugDrawFunc(&world, args...)
				},
			},	
			"step" : &tender.UserFunction{
				Name: "step",
				Value: FuncAf64iiR(world.Step),
			},	
			"create_body": &tender.UserFunction{
				Name:  "create_body",
				Value: func(args ...tender.Object) (tender.Object, error) {
					if len(args) != 1 { 
						return nil, tender.ErrWrongNumArguments 
					}
					
					bodyDef := box2d.MakeB2BodyDef()
					
					m, ok := args[0].(*tender.Map)
					if !ok {
						return nil, nil
					}
					
					if val, ok := m.Value["type"]; ok {
						bodyType, _ := tender.ToUint8(val)
						bodyDef.Type = bodyType 
					}
					
					if val, ok := m.Value["angle"]; ok {
						bodyAngle, _ := tender.ToFloat64(val)
						bodyDef.Angle = bodyAngle 
					}
					
					if val, ok := m.Value["angulardamping"]; ok {
						bodyAngularDamping, _ := tender.ToFloat64(val)
						bodyDef.AngularDamping = bodyAngularDamping 
					}	
					
					if val, ok := m.Value["lineardamping"]; ok {
						bodyLinearDamping, _ := tender.ToFloat64(val)
						bodyDef.LinearDamping = bodyLinearDamping 
					}	
					
					if val, ok := m.Value["gravityscale"]; ok {
						bodyGravityScale, _ := tender.ToFloat64(val)
						bodyDef.GravityScale = bodyGravityScale 
					}
					
					if val, ok := m.Value["bullet"]; ok {
						bodyBullet, _ := tender.ToBool(val)
						bodyDef.Bullet = bodyBullet 
					}
					
					if val, ok := m.Value["active"]; ok {
						bodyActive, _ := tender.ToBool(val)
						bodyDef.Active = bodyActive 
					}	
					
					if val, ok := m.Value["allowsleep"]; ok {
						bodyAllowSleep, _ := tender.ToBool(val)
						bodyDef.AllowSleep = bodyAllowSleep 
					}
					
					if val, ok := m.Value["awake"]; ok {
						bodyAwake, _ := tender.ToBool(val)
						bodyDef.Awake = bodyAwake
					}	
					
					if val, ok := m.Value["fixedrotation"]; ok {
						bodyFixedRotation, _ := tender.ToBool(val)
						bodyDef.FixedRotation = bodyFixedRotation
					}
					
					px := 0.0
					py := 0.0	
					vx := 0.0
					vy := 0.0
					
					if val, ok := m.Value["x"]; ok {
						px, _ = tender.ToFloat64(val)
					}
					if val, ok := m.Value["y"]; ok {
						py, _ = tender.ToFloat64(val)
					}
					if val, ok := m.Value["vx"]; ok {
						vx, _ = tender.ToFloat64(val)
					}
					if val, ok := m.Value["vy"]; ok {
						vy, _ = tender.ToFloat64(val)
					}
					
					bodyDef.Position = box2d.B2Vec2{X: px, Y: py}
					bodyDef.LinearVelocity = box2d.B2Vec2{X: vx, Y: vy}
					
					body := world.CreateBody(&bodyDef)
					
					
					return makeBox2dBody(body), nil
				},
			},	
		},
	}, nil
}
